
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RifatRubayatul
 */
public class Missile extends Balling {
    
    public Missile(double x, double y, AnchorPane root, double radius, Color color, int direction, int canonAngle) {
        super(x, y, root, radius, color, direction, canonAngle);
        
         damage=15;
         damageRadius=45;
        if(direction==1)
           fireImage=new Image("missile1.png");
        else
           fireImage=new Image("missile2.png");
       iv2 = new ImageView(fireImage);
       iv2.setX(initialX);
       iv2.setY(initialY);
       root.getChildren().add(iv2);
    }
    
}
